// src/realtime.js

/**
 * Realtime (WebRTC) – POC2
 * - Connecte une session Realtime via /api/realtime/session (SDP offer/answer)
 * - Injecte des instructions projet (contexte) via session.update
 * - Optionnel : envoie un warmup + response.create pour valider que ça parle bien
 */

let pc = null;
let dc = null;
let localStream = null;
let remoteAudioEl = null;

function buildRealtimeInstructions() {
  return `
Tu es “le Compagnon”, assistant vocal de démonstration pour un projet universitaire de jeu narratif destiné à des étudiants de musicologie.

Cadre :
- Tu réponds uniquement sur le projet, son prototype, son fonctionnement, ses limites, et comment l’utiliser.
- Si la question sort du cadre (politique, actualités, santé, etc.), tu refuses poliment et tu rediriges vers l’équipe humaine.
- Tu ne dois jamais inventer des infos sur le projet. Si tu ne sais pas : tu poses une question courte ou tu dis "je ne sais pas encore".
- Style : clair, concret, bienveillant, phrases courtes, orienté démo.
- Tu peux expliquer les choix techniques à un public avec des bases en informatique, sans jargon.

Objectif de la démo :
- Montrer une conversation vocale fluide.
- Expliquer le rôle de l’agent dans le projet.
- Rester strictement dans le cadre ci-dessus.
`.trim();
}

function ensureRemoteAudioEl(dom) {
  if (remoteAudioEl) return remoteAudioEl;

  remoteAudioEl = document.createElement("audio");
  remoteAudioEl.autoplay = true;
  remoteAudioEl.controls = true; // utile en debug
  remoteAudioEl.style.width = "100%";
  remoteAudioEl.style.marginTop = "8px";

  // On l’accroche dans la card “Real time” si possible, sinon en fin de body
  const card = dom?.realTime?.closest?.(".card");
  (card || document.body).appendChild(remoteAudioEl);

  return remoteAudioEl;
}

function sendSessionUpdate() {
  if (!dc || dc.readyState !== "open") return;

  const instructions = buildRealtimeInstructions();

  dc.send(
    JSON.stringify({
      type: "session.update",
      session: {
        instructions,
        turn_detection: {
          type: "server_vad",
          create_response: false,      // important : pas d’auto-réponse tant qu’on n’a pas cadré
          interrupt_response: false,   // évite les coupures/restarts “automatiques”
          idle_timeout_ms: 120000,
        },
        // Optionnel : si tu veux fixer une voix côté realtime
        // voice: "alloy",
      },
    })
  );
}

function sendWarmupAndRespond() {
  if (!dc || dc.readyState !== "open") return;

  // Message d’amorçage : vérifie que le contexte est bien pris
  dc.send(
    JSON.stringify({
      type: "conversation.item.create",
      item: {
        type: "message",
        role: "user",
        content: [
          {
            type: "input_text",
            //text: "Présente-toi en 1 phrase et rappelle ton cadre d’intervention.",
            text: "Peux tu rappeler à quel public le jeu narratif est destiné stp ?",
          },
        ],
      },
    })
  );

  // Demande une réponse
  dc.send(JSON.stringify({ type: "response.create" }));
}

/**
 * Retourne true si une connexion est en cours / établie (approx).
 */
export function isRealtimeConnected() {
  return !!pc && (pc.connectionState === "connecting" || pc.connectionState === "connected");
}

/**
 * Ferme proprement la session.
 */
export async function disconnectRealtime() {
  try {
    if (dc && dc.readyState === "open") dc.close();
  } catch {}

  try {
    if (pc) pc.close();
  } catch {}

  if (localStream) {
    localStream.getTracks().forEach((t) => t.stop());
    localStream = null;
  }

  if (remoteAudioEl) {
    remoteAudioEl.pause();
    remoteAudioEl.srcObject = null;
    // tu peux le garder visible (debug) ou le virer :
    // remoteAudioEl.remove();
    // remoteAudioEl = null;
  }

  pc = null;
  dc = null;
}

/**
 * Connecte la session realtime.
 * @param {object} opts
 * @param {object} opts.dom - objet retourné par getDom()
 * @param {(dom, status:string) => void} opts.setStatus - helper UI
 * @param {boolean} [opts.warmup=true] - envoie le warmup + response.create
 * @param {boolean} [opts.debug=true] - logs WebRTC
 */
export async function connectRealtime({ dom, setStatus, warmup = true, debug = true } = {}) {
  // Si on clique plusieurs fois : on repart propre
  await disconnectRealtime();

  setStatus?.(dom, "realtime: connecting…");

  pc = new RTCPeerConnection();

  if (debug) {
    pc.onconnectionstatechange = () => console.log("pc.connectionState =", pc.connectionState);
    pc.oniceconnectionstatechange = () => console.log("pc.iceConnectionState =", pc.iceConnectionState);
    pc.onicegatheringstatechange = () => console.log("pc.iceGatheringState =", pc.iceGatheringState);
    pc.onsignalingstatechange = () => console.log("pc.signalingState =", pc.signalingState);
  }

  // Data channel
  dc = pc.createDataChannel("oai-events");

  dc.onopen = () => {
    if (debug) console.log("datachannel open");
    setStatus?.(dom, "realtime: connected");

    // 1) injecter contexte
    sendSessionUpdate();

    // 2) amorçage optionnel
    //if (warmup) sendWarmupAndRespond();
  };



  let didUpdate = false;
  let didWarmup = false;

  dc.onmessage = (e) => {
    if (!debug) return;

    try {
      const evt = JSON.parse(e.data);
      console.log("evt:", evt.type, evt);

      if (evt.type === "session.created" && !didUpdate) {
        didUpdate = true;
        sendSessionUpdate(); // instructions ici
      }

      if (evt.type === "session.updated" && warmup && !didWarmup) {
        didWarmup = true;
        sendWarmupAndRespond(); // warmup ici
      }

      if (evt.type === "error") {
        console.error("REALTIME ERROR", evt.error);
      }
    } catch {
      console.log("evt(raw):", e.data);
    }
  };



  dc.onclose = () => {
    if (debug) console.log("datachannel closed");
  };

  // Audio sortant (micro)
  localStream = await navigator.mediaDevices.getUserMedia({ 
    audio: {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
    }
  });
  localStream.getTracks().forEach((track) => pc.addTrack(track, localStream));

  // Audio entrant (voix modèle)
  const audioEl = ensureRemoteAudioEl(dom);
  pc.ontrack = (event) => {
    audioEl.srcObject = event.streams[0];
  };

  // SDP offer -> server -> answer
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);

  const resp = await fetch("/api/realtime/session", {
    method: "POST",
    headers: { "Content-Type": "application/sdp" },
    body: offer.sdp,
  });

  if (!resp.ok) {
    const txt = await resp.text().catch(() => "");
    await disconnectRealtime();
    throw new Error(`Realtime session error ${resp.status}: ${txt || resp.statusText}`);
  }

  const answerSdp = await resp.text();
  await pc.setRemoteDescription({ type: "answer", sdp: answerSdp });

  return true;
}
